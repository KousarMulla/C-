#include "Math.h"
#include "stdafx.h"
int add(int a, int b)
{
	return (a+b);
}
